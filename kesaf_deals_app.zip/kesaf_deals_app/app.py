import csv
import datetime
import json

from flask import Flask, render_template, redirect, url_for, request
import os
import requests

from util import extract_simplex_data, extract_pzdeals_data

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
API_KEY = ""

app = Flask(
    __name__,
    static_url_path='/static'
)
files_list = []


@app.route('/upload', methods=['POST'])
def upload_file():
    global files_list

    if 'file' not in request.files:
        return 'No file part'

    file = request.files['file']

    if file.filename == '':
        return 'No selected file'

    if file:
        # Save the file to a location of your choice
        file.save(file.filename)
        files_list.append([file.filename, datetime.datetime.now()])
        return 'File uploaded successfully'


# Home page route
@app.route('/scraping')
def scraping():
    return render_template('scraping.html', scraping_files=files_list)


@app.route('/fetch_data')
def fetch_data():
    now = datetime.datetime.now()
    now = now.strftime("%y%m%d_%H%M%S")
    pz_deals_output_path = BASE_DIR + '/output/pz_deals/' + now
    simplex_output_path = BASE_DIR + '/output/simplex/' + now
    extract_simplex_data(simplex_output_path)
    extract_pzdeals_data(pz_deals_output_path)
    return redirect(url_for('scraping'))


@app.route('/track_products/<filename>')
def track_products(filename):
    try:
        # Open the CSV file with comma delimiter
        with open(filename, 'r', newline='') as csvfile:
            csv_reader = csv.reader(csvfile, delimiter=',')
            # Read the data into a variable
            data = [row for row in csv_reader]

        for key in data[1:]:
            body = {
                "asin": key[1],
                "ttl": 0,
                "expireNotify": True,
                "desiredPricesInMainCurrency": True,
                "mainDomainId": 1,
                "updateInterval": 1,
                "thresholdValues": [
                    {
                        "thresholdValue": 100,
                        "domain": 1,
                        "csvType": 2,
                        "isDrop": True
                    }
                ],
                "notifyIf": [],
                "notificationType": [
                    False,
                    False,
                    False,
                    False,
                    False,
                    True,
                    False
                ],
                "individualNotificationInterval": -1
            }
            add_response = add_tracking(API_KEY, body)
        return redirect(url_for("keepa"))

        return f"Data read successfully: {data}"
    except FileNotFoundError:
        return "File not found"
    except Exception as e:
        return f"An error occurred: {e}"


def add_tracking(api_key, tracking_data):
    url = f"https://api.keepa.com/tracking?key={api_key}&type=add"
    headers = {'Content-Type': 'application/json'}
    payload = json.dumps(tracking_data)
    response = requests.post(url, headers=headers, data=payload)
    return response.json()


def fetch_keepa_list():
    url = f"https://api.keepa.com/tracking?key={API_KEY}&type=list"
    headers = {'Content-Type': 'application/json'}
    response = requests.get(url, headers=headers)
    return response.json()


def get_named_lists(api_key):
    url = f"https://api.keepa.com/tracking?key={api_key}&type=list"
    headers = {'Content-Type': 'application/json'}
    response = requests.get(url, headers=headers)
    return response.json()


# Home page route
@app.route('/dashboard')
def dashboard():
    return render_template('kesaf_dashboard.html')


# Home page route
@app.route('/keepa')
def keepa():
    api_key = ''
    named_lists_response = get_named_lists(api_key)
    print(named_lists_response['trackings'][0])
    trackings = named_lists_response['trackings']
    trackings = sorted(trackings, key=lambda x: x['asin'])
    return render_template('keepa.html', keepa_data=trackings)


if __name__ == '__main__':
    app.run(debug=True)
